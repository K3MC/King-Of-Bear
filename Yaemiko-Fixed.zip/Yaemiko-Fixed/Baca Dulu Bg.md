<p align="center">
    <img src="./media/broad1.jpg" width="100%" style="margin-left: auto;margin-right: auto;display: block;">
</p>
<h1 align="center">Yaemiko Multidevices</h1>


### 📮 S&K
1. Dilarang Keras Menghapus Thanks Too
2. Sebelum Pakai Jangan Lupa Ubah Di config.js
3. Masukan Apikeymu Agar Work Fiturnya
4. Jangan Salah Gunakan Script Ini!

---------


## Thanks To
```bash
Author : Shirokami Ryzen 
Thanks : Narutomo, Elaina, Ekuzika, David, Vyna
Recode : Zeltoria 
